import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import type { Language } from "../utils/translations";

export default function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  return (
    <select
      value={language}
      onChange={(e) => setLanguage(e.target.value as Language)}
      data-ocid="nav.language.select"
      className="bg-eco-light border border-eco-primary/30 rounded-full px-3 py-1.5 text-sm font-semibold text-eco-dark focus:outline-none focus:ring-2 focus:ring-eco-primary cursor-pointer appearance-none pr-7 relative"
      style={{
        backgroundImage:
          "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%232d6a4f' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E\")",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "right 10px center",
      }}
    >
      <option value="en">🌐 English</option>
      <option value="hi">हिंदी</option>
      <option value="mr">मराठी</option>
    </select>
  );
}
